"""
 Basic webservice application

"""

import json


USERS = [
    {
        "id": 1,
        "name": "Ana",
        "age": 22,
    },
    {
        "id": 2,
        "name": "Paulo",
        "age": 25,
    }
]

def response_ok(body):
    return {
            'status': '200 OK',
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps(body),
            }
def not_found(body):
    return {
            'status': '404 Not Found',
            'headers': {},
            'body': body
    }
def replace_value(user, key, newValue):
    for k in user.keys():
        if k == key:
            user[k] = newValue
            return

def controller(request):
    """Handles a request and returns a response."""
    print(request['method'])
    if request['method'] == 'GET':
        url = request['url']
        url_parts = url.split("/")
        if (len(url_parts) > 1 and url_parts[1] =='users'):
            if (len(url_parts)==2 or (len(url_parts)==3 and url_parts[2]=='')):
                return response_ok(USERS)
            else:
                for user in USERS:
                    if (user.get("id") == int(url_parts[2])):
                        return response_ok(user)
        return not_found('Registo não encontrado')

    if request['method'] == 'POST':
        user = json.loads(request['body'])
        USERS.append(user);
        return response_ok(USERS)

    if request['method'] == 'DELETE':
        url = request['url']
        url_parts = url.split("/")
        if (len(url_parts) > 1 and url_parts[1] =='users'):
            if (len(url_parts)==2 or (len(url_parts)==3 and url_parts[2]=='')):
                return not_found('Faltou indicar o user a remover')
            else:
                for user in USERS:
                    if (user.get("id") == int(url_parts[2])):
                        USERS.remove(user)
                        return response_ok(USERS)
        return not_found('Registo não encontrado')

    if request['method'] == 'PUT':
        url = request['url']
        url_parts = url.split("/")
        if (len(url_parts) > 1 and url_parts[1] =='users'):
            if (len(url_parts)==2 or (len(url_parts)==3 and url_parts[2]=='')):
                return not_found('Faltou indicar o user a atualizar')
            else:
                for user in USERS:
                    if (user.get("id") == int(url_parts[2])):
                        newDict = json.loads(request['body'])
                        for key in newDict:
                            replace_value(user,key,newDict.get(key))
                        return response_ok(USERS)
        return not_found('Registo não encontrado')

    else:
        return not_found('Método não disponível');
